This is just a text file.
